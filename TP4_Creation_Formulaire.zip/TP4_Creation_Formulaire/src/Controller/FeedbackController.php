<?php
// src/Controller/FeedbackController.php

namespace App\Controller;

use App\Entity\Feedback;
use App\Form\FeedbackType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\FormFactoryInterface;

/**
 * @Route("/feedback")
 */
class FeedbackController extends AbstractController
{
    private $entityManager;
    private $formFactory;

    public function __construct(EntityManagerInterface $entityManager, FormFactoryInterface $formFactory)
    {
        $this->entityManager = $entityManager;
        $this->formFactory = $formFactory;
    }

    /**
     * @Route("/", name="feedback", methods={"GET", "POST"})
     */
    public function feedback(Request $request): Response
    {
        // Créez une instance de l'entité Feedback
        $feedback = new Feedback();

        // Utilisez directement le service FormFactoryInterface pour créer le formulaire
        $form = $this->formFactory->create(FeedbackType::class, $feedback);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Traitez les données ici
            $this->entityManager->persist($feedback);
            $this->entityManager->flush();

            // Ajoutez un message flash pour indiquer le succès
            $this->addFlash('success', 'Feedback soumis avec succès!');

            // Redirigez vers la page du formulaire
            return $this->redirectToRoute('feedback');
        }

        return $this->render('feedback/index.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}

